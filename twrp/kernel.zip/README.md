Place "Image.gz-dtb" file to this directory and pack

PS: Image.gz-dtb has been updated! Now it is the latest kernel of litehunter

Note: Evilhunter and Litehunter is different (EH - HMP and Overdrivered, LH - EAS and optimized with all essential and neccesarry drivers)

* If you want to hack everything, except GTP and etc things, you must you evilhunter kernel
* If you want to hack simple things like wifi, bluetooth and etc, with full optimization and battery savers, you must use only litehunter kernel
